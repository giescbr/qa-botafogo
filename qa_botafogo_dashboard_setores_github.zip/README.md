# Dashboard QA — Botafogo

Site estático para GitHub Pages com:

- login por perfil;
- importação de planilha apenas pelo usuário QA;
- dashboard de temperatura;
- dashboard de pontuação por setor com filtro: COZINHA, SUSHIBAR, EXPEDIÇÃO e ESTOQUE.

## Arquivos principais

- `index.html`: página do site.
- `dados.xlsx`: planilha modelo que o site tenta carregar automaticamente.
- `.nojekyll`: arquivo vazio para evitar processamento Jekyll no GitHub Pages.

## Como atualizar os dados para todos visualizarem

Substitua o arquivo `dados.xlsx` no GitHub mantendo exatamente esse nome. Depois que o GitHub Pages atualizar, os usuários que entrarem no site verão a planilha atualizada automaticamente.

## Como editar a pontuação por setor

Nas abas `COZINHA`, `SUSHIBAR`, `EXPEDIÇÃO` e `ESTOQUE`:

- `1` na coluna SIM/NÃO = sim, adiciona o ponto.
- `0` na coluna SIM/NÃO = não, não adiciona o ponto.
- A Nota Final é calculada automaticamente como Nota Base + Pontos Adicionados.

## Atenção

Como o GitHub Pages é estático, o login protege apenas visualmente a interface. Para dados sensíveis, use uma solução com autenticação real, como SharePoint, Power BI ou backend com login.
